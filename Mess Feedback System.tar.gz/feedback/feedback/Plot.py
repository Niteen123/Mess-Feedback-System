#!/usr/bin/python

import matplotlib.pyplot as plt
import numpy as np
import csv, sys, re, random, os, time

datfile="Data.txt"
Mcsv = csv.reader(open(datfile, 'r'), delimiter=',', quotechar='"')

# Mapping from column name to column index
I = {}

# Matrix of all the rows
M = []

rowNum = 0
for row in Mcsv:
    rowNum += 1
    if (rowNum == 1):
        for i in range(len(row)):
            I[row[i]] = i
        continue
    else:
        M.append(row)
        
#print(len(M[0]))

name = map(lambda r: (r[I['User_Name']]), M)
date = map(lambda r: (r[I['Date']]), M)
cleanliness = map(lambda r: (r[I['Cleanliness_of_utensils']]), M)
category = map(lambda r: (r[I['Complaint_Category']]), M)
sweets = map(lambda r:(r[I['Quantity_of_sweets_served']]), M)
rating = map(lambda r: (r[I['Overall_Rating']]), M)
suggestions = map(lambda r: (r[I['Suggestions']]), M)
quality = map(lambda r: (r[I['Quality_and_taste_of_food']]), M)

name_list=list(name)
date_list=list(date)
cleanliness_list=list(cleanliness)
category_list=list(category)
sweets_list=list(sweets)
rating_list=list(rating)
suggestions_list=list(suggestions)
quality_list=list(quality)

quality_exec=0
quality_good=0
quality_below=0
for itr in quality_list:
	if(itr=="Excellent"):
		quality_exec=quality_exec+1
	if(itr=="Good"):
		quality_good=quality_good+1
	if(itr=="Below Par"):
		quality_below=quality_below+1
		
#print(quality_exec,quality_good,quality_below)

list1=['Excellent','Good','Below Par']
quality_col=[quality_exec,quality_good,quality_below]
width = 0.30
plt.figure(figsize=(6, 5))
r1 = plt.bar(list1, quality_col, width, color='r')
plt.title('Food Quality')
plt.xlabel('Quality and taste of food')
plt.ylabel('Count')
plt.show()
#plt.savefig("Quality_Food.pdf", bbox_inches='tight')

clean_exec=0
clean_good=0
clean_bad=0
for itr in cleanliness_list:
	if(itr=="Excellent"):
		clean_exec=clean_exec+1
	if(itr=="Good"):
		clean_good=clean_good+1
	if(itr=="Very Bad"):
		clean_bad=clean_bad+1
		
#print(clean_exec,clean_good,clean_bad)

list1=['Excellent','Good','Very Bad']
clean_col=[clean_exec,clean_good,clean_bad]

plt.figure(figsize=(6, 5))
r1 = plt.bar(list1, clean_col, width, color='r')
plt.title('Cleanliness')
plt.xlabel('Cleanliness of utensils')
plt.ylabel('Count')
plt.show()
#plt.savefig("Cleanliness.pdf", bbox_inches='tight')

cat_food=0
cat_bill=0
cat_other=0
for itr in category_list:
	if(itr=="Food"):
		cat_food=cat_food+1
	if(itr=="Bill Issue"):
		cat_bill=cat_bill+1
	if(itr=="Any Other"):
		cat_other=cat_other+1
		

#print(cat_food,cat_bill,cat_other)

plt.figure(figsize=(6, 5))
list1=['Food','Bill Issue','Any Other']
clean_col=[cat_food,cat_bill,cat_other]
r1 = plt.bar(list1, clean_col, width, color='r')
plt.title('Complaint Category')
plt.xlabel('Complaint Category')
plt.ylabel('Count')
plt.show()
#plt.savefig("Complaint.pdf", bbox_inches='tight')

sweet_less=0
sweet_right=0
sweet_more=0
for itr in sweets_list:
	if(itr=="Less"):
		sweet_less=sweet_less+1
	if(itr=="Just Right"):
		sweet_right=sweet_right+1
	if(itr=="More"):
		sweet_more=sweet_more+1
		
plt.figure(figsize=(6, 5))
list1=['Less','Just Right','More']
sweet_col=[sweet_less,sweet_right,sweet_more]
r1 = plt.bar(list1, sweet_col, width, color='r')
plt.title('Sweets Quantity')
plt.xlabel('Quantity of sweets served')
plt.ylabel('Count')
plt.show()
#plt.savefig("Quantity.pdf", bbox_inches='tight')

rating_good=0
rating_ok=0
rating_bad=0
for itr in rating_list:
	if(itr=="good"):
		rating_good=rating_good+1
	if(itr=="ok"):
		rating_ok=rating_ok+1
	if(itr=="bad"):
		rating_bad=rating_bad+1

plt.figure(figsize=(6, 5))
list1=['Good','Ok','Bad']
rating_col=[rating_good,rating_ok,rating_bad]
r1 = plt.bar(list1, rating_col, width, color='r')
plt.title('Overall Rating')
plt.xlabel('Overall Rating')
plt.ylabel('Count')
plt.show()
#plt.savefig("Rating.pdf", bbox_inches='tight')

