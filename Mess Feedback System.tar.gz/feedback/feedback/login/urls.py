from django.urls import path
from . import views
from django.contrib.auth import views as auth_views 

urlpatterns = [
    path('', views.index, name='index'),
    path('contact/', views.contact, name='contact'),
    path('about/', views.about,name = 'about'),
    path('logins/', views.login,name = 'login'),
    path('register/', views.register,name = 'register'),
    path('response/', views.response,name = 'response'),
    path('form/' ,views.form,name ='form'),
    path('forgotpassword/' ,views.forgotpassword,name ='forgotpassword'),
    path('forgot/' ,views.forgot,name ='forgot'),
    path('verification/' ,views.verification,name ='verification'),
    path('logout/' ,views.logout,name ='logout'),
    path('root/' ,views.root,name ='root'),
    path('res/' ,views.res,name ='res'),
    path('logout_view/' ,views.logout_view,name ='logout_view'),
    path('root_resp/' ,views.root_resp,name ='root_resp'),
    path('root_feedback/' ,views.root_feedback,name ='root_feedback'),
]


