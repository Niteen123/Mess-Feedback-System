
from profile import Profile
from django.http import HttpResponse
from django.template import loader
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib import messages , auth
from login.models import registered  #table name registered and feed
from login.models import feed as resp
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth import authenticate
from django.contrib.auth import login as auth_login
from django.core.mail import send_mail
from django.contrib.auth import logout
from datetime import datetime
# from django.shortcuts import render_to_response


username=""
password=""
def index(request):
	template = loader.get_template('index.html')
	return HttpResponse(template.render())

def login(request):
	return render(request,'logins.html')

def about(request):
	return render(request,'about.html')

def contact(request):
	return render(request,'contact.html')

def register(request):
	return render(request,'register.html')
	
def response(request):
	return render(request,'response.html')

def forgotpassword(request):
	return render(request,'forgotpassword.html')

def logout(request):
	return render(request,'logout.html')

def root(request):
	return render(request,'sample.html')

def root_resp(request):
	return render(request,'root_resp.html')

def form(request):
	if request.method == 'POST':
		# print("inside if")
		username = request.POST['username']
		email = request.POST['email']
		password = request.POST['password']
		password2 = request.POST['password2']
		if password==password2:
			# print("both same")
			if User.objects.filter(username=username).exists():
				print("\nuser exits")
				messages.info(request, 'username already exists!')
				return redirect('/login/register')
			elif User.objects.filter(email=email).exists():
				print("\nemail exists")
				messages.info(request, 'email already exists!')
				return redirect('/login/register')
			else:
				print("\nsuccess")
				detail = registered(username=username,email=email,password=password)
				detail.save()
				return redirect('/login/logins')
		else:
			print("else")
			messages.info(request,'password do not match')
			return redirect('/login/register')
	else:
		return render(request,'/login/register')

def forgot(request):
	# print("forgot")
	email = request.POST['email']
	password = registered.objects.all()
	password =registered.objects.values_list('email','password')
	flag=0
	for email2 in password:
		email3=list(email2)
		if(email == email3[0]):
			flag=1
			# print (email3[1])
			send_mail('Your OTP for Verification', 'Your Password is {}'.format(email3[1]),'f7249647@gmail.com',['22m0814@iitb.ac.in'],fail_silently=False)
			messages.error(request,"Password Sent to Your ID please Login Again")
		else:
			pass
	if (flag==0):
		messages.error(request,"User Doesn't Exist!!")
		#print(password)
	return redirect('/login/forgotpassword')

def verification(request):
	v=0
	username2 = request.POST['username']
	password2 = request.POST['password']
	if(username2 == 'root'):
		if (password2 == 'root'):
			return redirect("/login/root/")
	# table name registered
	verify =registered.objects.values_list('username','password')
	for verifylist in verify:
		ver=list(verifylist)
		if (username2 == ver[0]):
			if(password2 == ver[1]):
				v=1
				return redirect("/login/response/")
			# else:
			# 	pass
				# messages.error(request,"wrong password")
	if(v==0):
		messages.error(request,"Wrong Credentials")
		return redirect('/login/logins/')
def res(request):
	username=request.POST['username']
	date = request.POST['date']
	# print(username)
	# print(date)
	quality =  request.POST.get('quality')
	Cleanliness = request.POST.get('Cleanliness')
	complaint =  request.POST.get('complaint')
	Quantity =  request.POST.get('Quantity')
	Overall =  request.POST.get('Overall')
	suggestion = request.POST['suggestion']
	# print("checkpoint")
	verify =registered.objects.values_list('username','password')
	# print(verify)
	# print("check1")
	for verifylist in verify:
		ver=list(verifylist)
		# print("check2")
		# print(ver[0])
		if (username == ver[0]):
			# print("check3")
			detail = resp(Cleanliness=Cleanliness,date=date,quality=quality,username=username,complaint=complaint,Quantity=Quantity,overall=Overall,suggestion=suggestion)
			detail.save()
			return redirect('/login/logout/')


def logout_view(request):
	logout(request)
	return HttpResponseRedirect('/login/logout')

def root_feedback(request):
	# data=resp.objects.values_list('username','date','quality','Cleanliness','Quantity','overall','suggestion')
	# data=resp.objects.values_list()
	from_date = request.POST.get('date')
	to_date=request.POST.get('date1')
	# print(from_date)
	# print(to_date)
	# from_date1=from_date.strftime("%m/%d/%Y")
	# to_date1=to_date.strftime("%m/%d/%Y")
	data=resp.objects.all()
	# date2=data[1]
	# date2=data[0]
	# print(date2[1])
	count=0
	data_f=[]
	for dat in data:
		
		date1=dat.date.strftime("%Y-%m-%d")
		# print(date)
		# print("insidefor")
		if(date1 >= from_date ):
			if(date1 <= to_date):
				# print("insideif")
				print(dat.date)
				data_f=data[count]
		count=count+1
	print(data_f)
	return render(request,'root_resp.html', { 'data':data})
		