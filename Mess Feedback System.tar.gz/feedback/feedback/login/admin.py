from django.contrib import admin
from .models import registered
# Register your models here.

admin.site.register(registered)
