from django.db import models
from django.contrib.auth import get_user_model

User =get_user_model

# class Login(models.Model):
# 	username = models.CharField(max_length=255)
# 	email = models.EmailField(verbose_name='email') 
# 	password = models.CharField(max_length=50)
#   #rollno = models.IntegerField

class registered(models.Model):
	username = models.CharField(max_length=255)
	email = models.EmailField(verbose_name='email')
	password = models.CharField(max_length=50, default="hello")

# Cleanliness_choice{


# }
class feed(models.Model):
	username=models.CharField(max_length=255)
	date = models.DateField()
	quality = models.CharField(max_length=255)
	Cleanliness = models.CharField(max_length=255)
	complaint = models.CharField(max_length=255)
	Quantity = models.CharField(max_length=255)
	overall = models.CharField(max_length=255)
	suggestion = models.CharField(max_length=255)

